<?php
session_start();
$username = $_SESSION["username"];
echo $username;
echo "<br>";
$added = $_SESSION["addedToCart"];
echo $added;

$purchase = $_SESSION["purchase"];
echo $purchase;
$uname = strip_tags($username);
$uname = htmlspecialchars($username);


?>
<html>
    <body>
        <a href="shoppingCart.php"> Click here for shopping cart</a>  <br> 
        <a href="editCustomer.php"> Edit profile</a>  <br> 
         <a href="transactions.php"> Click here for all transactions</a>  <br>  
        <h1><b>Book List</b></h1>
        <table id = "table1">   
            <tr>
                <th>BookID</th>
                <th>Book name</th>
                <th>Book type</th>
                <th>Book material</th>
                <th>Book price</th>
                <th>Number of Books left</th>
                <th>Store Location</th> 
                <th>Quantity to buy</th>
                <th>Add to Cart</th>

            </tr>
            <?php
            $query = "SELECT book.bookID, book.bookTitle,book.bookType, book.bookMaterial, book.bookPrice, book.bookQuantity,store.city,store.state FROM book, store WHERE store.storeID = book.StoreID";
            include('databaseConnect.php');
            $result = mysqli_query($connect, $query);
            while($row = mysqli_fetch_assoc($result)){
                echo 
                    "<tr>
                                <td>".$row["bookID"]. "</td>
                                <td>" . $row["bookTitle"]. "</td>
                                <td>" . $row["bookType"]."</td>
                                <td>" . $row["bookMaterial"]."</td>
                                <td>$" . $row["bookPrice"]. "</td>
                                <td>" . $row["bookQuantity"]."</td>
                                 <td>" . $row["city"]."</td>";
                echo "<td> <form method='post' action='addToShoppingCart.php?bookID=".$row['bookID']."'> 
               <input type='int' name='quantity'> </td>"; 
                echo "<td> <input type='submit' name='submit' value='Add to cart'></form></tr>";

            }

            ?>

        </table>
    </body>
</html>