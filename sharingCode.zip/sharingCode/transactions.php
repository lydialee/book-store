<?php
session_start();
$username = $_SESSION["username"];
echo $username;
echo "<br>";
$added = $_SESSION["addedToCart"];
echo $added;

$purchase = $_SESSION["purchase"];
echo $purchase;
$uname = strip_tags($username);
$uname = htmlspecialchars($username);


?>
<html>
    <body>
        <a href="shoppingCart.php"> Click here for shopping cart</a>  <br> 
         <a href="catalog.php"> Click here for main menu</a>  <br>  
        <h1><b>Transactions</b></h1>
        <table id = "table1">   
            <tr>
                <th>Order number</th>
                <th>date</th>
                   <th>Salesperson</th>
                <th>book ID</th>
                <th>book Quantity</th>
                <th>Book price</th>
                <th>CustomerID</th>
                <th>First name</th> 
                <th>Last name</th>
                <th>Store Location</th>

            </tr>
            <?php
            $query = "SELECT * FROM transactions";
            include('databaseConnect.php');
            $result = mysqli_query($connect, $query);
            while($row = mysqli_fetch_assoc($result)){
                echo 
                    "<tr>
                                <td>".$row["orderNumber"]. "</td>
                                <td>" . $row["date"]. "</td>
                                <td>" . $row["salespersonID"]."</td>
                                <td>" . $row["bookID"]."</td>
                                <td>" . $row["bookQuantity"]. "</td>
                                <td>$" . $row["bookPrice"]."</td>
                                <td>" . $row["customerID"]."</td>
                                 <td>" . $row["fname"]."</td>
                                  <td>" . $row["lname"]."</td>
                                 <td>" . $row["storeID"]."</td>";
    

            }

            ?>

        </table>
    </body>
</html>